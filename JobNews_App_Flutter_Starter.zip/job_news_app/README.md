# JobNews — Jobs & Scholarship Portal

Flutter starter project for a professional mobile jobs/news portal.

## Included UI
- Mandatory login with email/mobile + password
- OTP verification screen (UI placeholder)
- Home/news-portal layout
- Government jobs, private jobs and state-wise browsing
- Scholarship section
- Job detail and Apply Now flow placeholder
- My Applications tracking screen
- Profile, resume/documents and employer/HR entry points
- Modern Material 3 responsive design

## Production integrations still required
The UI is runnable, but live services require external configuration:
- Real OTP: Firebase Authentication or an SMS/email OTP provider
- Database: Firestore/PostgreSQL/etc.
- Resume/document storage
- Push notifications
- Admin dashboard
- Authorized government/public job feeds or APIs
- Authorized private-company feeds/APIs
- Employer verification and job moderation
- Authorized in-app application APIs/forms, or official application links where direct submission is not available

Do not scrape or republish protected job data without permission. Use official/public APIs or feeds where permitted.

## Run
1. Install Flutter SDK.
2. From this folder run `flutter pub get`.
3. Run `flutter run` on Android emulator or a connected device.
